# Projecto GPS_chapas
`C++`

	• Sketch Version: 03
	• Code Revisioned by: @gorsol & @kishannareshpal
	• Last updated: 31-03-2018
	• Description: Aplicação da tecnologia Open
	Hardware & Software na área de Mobilidade Urbana.

<br>	
	
	
| Hardware       |
| -------------  |
| [Arduino UNO R3](https://store.arduino.cc/arduino-uno-smd-rev3) |
| [Adafruit FONA GPRS+GPS Shield (SIM 808)](https://www.mouser.co.za/new/adafruit/adafruit-fona-808/) |
| ... |


| Used Libraries |
| -------------  |
| [Adafruit_FONA.h](https://github.com/adafruit/Adafruit_FONA) |
| ... |